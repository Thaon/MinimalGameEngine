function Start()

end

function Update()
	
end
